1. Push components using Salesforce CLI (DX Format) or convert to metadata API using Salesforce CLI command > sfdx force:source:convert
2. Do Data Load using provided CSV file (CostandFee.csv)
3. Activate Flow > Go to Setup > Process Automation > Flows > Update Contact Info from Settings > Activate Latest Version
4. Activate Process Builder > Go to Setup > Process Automation > Process > Builder > Contact Assigned to a Product > Activate Latest Version